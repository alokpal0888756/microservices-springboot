package org.npci.userservice.external.services;

public interface RatingService {
}
